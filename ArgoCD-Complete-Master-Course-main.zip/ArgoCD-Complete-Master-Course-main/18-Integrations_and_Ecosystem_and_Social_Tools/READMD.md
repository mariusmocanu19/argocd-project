# Integrations and Ecosystem and Social Tools

- Integrating ArgoCD with CI/CD Tools 
- Third-party Extensions and Plugins 
- Kubernetes Operators and Helm Charts 
- ArgoCD and Observability
- ArgoCD Integration with Slack
- Create issue in github on failure
- Send out notification
