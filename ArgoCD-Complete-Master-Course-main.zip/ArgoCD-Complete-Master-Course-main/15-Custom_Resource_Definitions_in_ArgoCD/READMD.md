# Custom Resource Definitions in ArgoCD
- Extending ArgoCD with Custom Resources 
- Creating Custom Tools and Plugins 
- Advanced Customizations
