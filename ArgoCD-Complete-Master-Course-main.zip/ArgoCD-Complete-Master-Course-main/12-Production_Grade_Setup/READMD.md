# Production Grade Setup

- Multi cloud application deployment
- Vultr Cloud setup
- ArgoCD in Vultr cloud
- Install ArgoCD in multi node cluster
- Access WebUI and CLI in multi node cluster
- Deploy application in multi node cluster


