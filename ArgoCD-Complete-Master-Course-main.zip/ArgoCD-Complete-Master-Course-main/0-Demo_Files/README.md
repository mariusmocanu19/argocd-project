# summary of folders and application details


## K8s files and Apps 

https://github.com/SMACAcademy/ArgoCD-Complete-Master-Course.git

- 0-Demo_Files/Demo_ConfigMap
- 0-Demo_Files/Demo_Deployment
- 0-Demo_Files/Demo_Service



- 0-Demo_Files/Nginx_Deployment
- 0-Demo_Files/Nginx_Deployment_Prune
- 0-Demo_Files/Sample_Deployment_Service


- 0-Demo_Files/Demo_Resource_Limit

## Apps


## Other Repo List

https://github.com/SMACAcademy/k8s-main-config.git

- deploy/production